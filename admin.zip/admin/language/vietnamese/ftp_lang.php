<?php

$lang['ftp_no_connection'] = 'Không tìm thấy kết nối hợp lệ.  Xin hãy đảm bảo rằng đã thực hiện kết nối tới máy chủ FTP trước khi thực hiện các thao tác khác.';
$lang['ftp_unable_to_connect'] = 'Không kết nối được tới máy chủ FTP với tên máy đã cung cấp.';
$lang['ftp_unable_to_login'] = 'Không đăng nhập được vào máy chủ FTP.  Xin kiểm tra lại tên đăng nhập và mật khẩu.';
$lang['ftp_unable_to_makdir'] = 'Không tạo được thư mục đã chỉ định.';
$lang['ftp_unable_to_changedir'] = 'Không đổi sang thư mục khác được.';
$lang['ftp_unable_to_chmod'] = 'Không đặt quyền cho tập tin được. Xin kiểm tra lại đường dẫn. Lưu ý: Tính năng này chỉ sử dụng được nếu hệ thống hoạt động với PHP phiên bản 5 trở lên.';
$lang['ftp_unable_to_upload'] = 'Không tải được tập tin đã chọn. Xin kiểm tra lại đường dẫn.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'Không tìm được tập tin nguồn. Xin kiểm tra lại đường dẫn.';
$lang['ftp_unable_to_rename'] = 'Không đổi được tên của tập tin hoặc thư mục.';
$lang['ftp_unable_to_delete'] = 'Không xóa được tập tin hoặc thư mục.';
$lang['ftp_unable_to_move'] = 'Không di chuyển được tập tin hoặc thư mục. Xin kiểm tra lại xem thư mục đích có tồn tại hay không.';
?>