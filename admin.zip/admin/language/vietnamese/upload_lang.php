<?php

$lang['upload_userfile_not_set'] = 'Không có biến nào tên là userfile trong dữ liệu POST.';
$lang['upload_file_exceeds_limit'] = 'Tập tin đã tải lên quá lớn so với dung lượng máy chủ cho phép đối với PHP.';
$lang['upload_file_exceeds_form_limit'] = 'Tập tin đã tải lên quá lớn so với dung lượng hệ thống cho phép.';
$lang['upload_file_partial'] = 'Chỉ một phần của tập tin được tải lên.';
$lang['upload_no_temp_directory'] = 'Thiếu thư mục tạm.';
$lang['upload_unable_to_write_file'] = 'Không ghi được tập tin lên trên máy chủ.';
$lang['upload_stopped_by_extension'] = 'Quá trình tải tập tin lên bị ngắt giữa chừng.';
$lang['upload_no_file_selected'] = 'Chưa chọn tập tin cần tải lên.';
$lang['upload_invalid_filetype'] = 'Tập tin vừa chọn không thuộc các kiểu tập tin được phép tải lên.';
$lang['upload_invalid_filesize'] = 'Tập tin vừa chọn có dung lượng lớn hơn giới hạn cho phép.';
$lang['upload_invalid_dimensions'] = 'Ảnh vừa tải lên có chiều rộng hoặc chiều cao quá lớn so với giới hạn cho phép.';
$lang['upload_destination_error'] = 'Gặp lỗi khi di chuyển tập tin đã tải lên sang thư mục đích.';
$lang['upload_no_filepath'] = 'Đường dẫn tải lên không hợp lệ.';
$lang['upload_no_file_types'] = 'Hệ thống chưa quy định các kiểu tập tin cho phép tải lên.';
$lang['upload_bad_filename'] = 'Tập tin vừa tải lên bị trùng tên với một tập tin đã có trên máy chủ.';
$lang['upload_not_writable'] = 'Hệ thống không có quyền ghi dữ liệu vào thư mục đích sẽ lưu tập tin tải lên.';
?>