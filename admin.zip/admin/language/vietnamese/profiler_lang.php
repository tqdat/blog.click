<?php

$lang['profiler_database'] = 'CSDL';
$lang['profiler_controller_info'] = 'LỚP/HÀM';
$lang['profiler_benchmarks'] = 'ĐO';
$lang['profiler_queries'] = 'TRUY VẤN';
$lang['profiler_get_data'] = 'GET';
$lang['profiler_post_data'] = 'POST';
$lang['profiler_uri_string'] = 'CHUỖI URI';
$lang['profiler_memory_usage'] = 'BỘ NHỚ';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'Trình điều khiển CSDL chưa được nạp';
$lang['profiler_no_queries'] = 'Chưa chạy câu truy vấn nào';
$lang['profiler_no_post'] = 'Không có dữ liệu POST';
$lang['profiler_no_get'] = 'Không có dữ liệu GET';
$lang['profiler_no_uri'] = 'Không có dữ liệu URI';
$lang['profiler_no_memory'] = 'Không thống kê được bộ nhớ đã dùng';
$lang['profiler_no_profiles'] = '';
?>