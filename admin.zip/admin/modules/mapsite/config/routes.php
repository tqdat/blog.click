<?php  
$route['sitemap'] = 'sitemap/index';
?>
