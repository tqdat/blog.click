<?php
class quangcao_model extends model{
    function __construct(){
        parent::__construct();
    }
}
