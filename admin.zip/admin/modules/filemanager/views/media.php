<iframe style="border: none;" src="<?=base_url()?>templates/ckeditor/kcfinder/browse.php?type=media" width="100%" height="400"></iframe>
