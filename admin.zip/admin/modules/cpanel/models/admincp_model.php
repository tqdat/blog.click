<?php
class admincp_model extends model{
    function __construct(){
        parent::__construct();
    }
}
