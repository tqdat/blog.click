<?php
$route['default_controller'] = "home";
$route['404_override'] = '';
