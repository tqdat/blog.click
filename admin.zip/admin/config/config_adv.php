<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File Config_site 
* Date: 18/07/13 23:36:58.
**/
$config['adv_active'] = 1;
$config['adv_left_name'] = '123';
$config['adv_left_link'] = '123';
$config['adv_left_img'] = 'adv_left.jpg';
$config['adv_right_name'] = '123';
$config['adv_right_link'] = '123';
$config['adv_right_img'] = 'adv_right.jpg';

/* End of file config_site*/