<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File Config_site 
* Date: 17/01/18 03:19:31.
**/
$config['site_name'] = 'Blog Thông Tin, Cẩm Nang Du Lịch - ClickGo.vn';
$config['site_email'] = 'info@clickgo.vn';
$config['site_facebook'] = 'https://www.facebook.com/clickgovn';
$config['site_skype'] = 'info@clickgo.vn';
$config['site_google'] = 'https://plus.google.com/u/0/108529155749205661251';
$config['site_close'] = 0;
$config['site_close_msg'] = 'Cảm ơn Quý khách.';
$config['site_des'] = 'Tổng hợp thông tin điểm đến, kinh nghiệm du lịch tại Việt Nam';
$config['site_keyword'] = 'Clickgo, thông tin du lịch, tour du lịch, khách sạn, vé máy bay';

/* End of file config_site*/