<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File config_seo 
* Date: 17/01/18 03:19:10.
**/
$config['cf_yahoo'] = '9C986EA4B640F9929613071A35C80FCB';
$config['cf_alexa'] = '16W05OCEYo1BLxQvM4Oz6bVwx4c';
$config['cf_google_webmaster'] = 'UA-39713580-4';
$config['cf_google_analytics'] = 'UA-39713580-4';

/* End of file config_seo*/