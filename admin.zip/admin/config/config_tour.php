<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['config_tour']    = ROOT."site/config/config_tour.php";
require_once($config['config_tour']);  
