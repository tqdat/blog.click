<?php
$config['xsl'] = 1;
$config['charset'] = 'utf-8';
$config['query_string'] = FALSE;
$config['suff'] = '';
// Language
$config['muti_language'] = TRUE;
$config['language'] = 'vi';

$config['encryption_key'] = 'zH1882Bf53L3zj50Fjay1lgBNF1A6Xf5ghjglhkj';
$config['csrf_protection'] = TRUE; // Hien thi Input trong Form
$config['csrf_name'] = 'token'; // Token Name
$config['store_session_table'] = true; // L&#432;u session trong db
$config['cookie_prefix']    = "";
$config['cookie_domain']    = "www.tuannguyentravel.com";
$config['cookie_path']        = "/";
$config['cookie_secure']    = FALSE;