<?php
$config['css_path'] = base_url().'templates/css/';
$config['js_path'] = base_url().'templates/js/';
