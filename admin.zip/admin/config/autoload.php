<?php
$autoload['libraries'] = array('session','form_validation','security','auth','pagination','esset','vcache');
$autoload['helper'] = array('url','form','icon','string','vstring','vorder');
$autoload['config'] = array('config_site');